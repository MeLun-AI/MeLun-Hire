# MeLun Dark Green + Dark Orange Brand Assets

The original MeLun logo design is unchanged.

## Approved palette
- True dark green: `#0A301B` → `#14522B`
- Dark orange: `#7D2A08` → `#BE490D`
- No olive green
- No white logo color
- Transparent backgrounds where appropriate

Only the colors were changed. The symbol, wordmark, proportions, typography, and layout remain unchanged.
